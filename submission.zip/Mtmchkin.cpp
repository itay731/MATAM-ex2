//
// Created by 97252 on 5/1/2022.
//

#include "Mtmchkin.h"


Competitors::Competitors(Player *newPlayer, Competitors *formerPlayer) {
    this->m_player=newPlayer;
    this->m_next= nullptr;
    if(formerPlayer!= nullptr) {
        formerPlayer->setNext(this);
    }
}

void Competitors::setNext(Competitors* nextPlayer) {
    this->m_next=nextPlayer;
}

Player* Competitors::getPlayer() {
    return this->m_player;
}

Competitors *Competitors::getNext() {
    return this->m_next;
}

Mtmchkin::Mtmchkin(const char *playerName, const Card *cardsArray, int numOfCards) {
    this->m_numOfPlayers=START_NUM_OF_PLAYERS;
    Player* newPlayer = new Player(playerName);
    this->m_competitors = new Competitors(newPlayer, nullptr);
    Card* gameCards = new Card[numOfCards];
    for (int i = 0; i < numOfCards; ++i) {
        gameCards[i]=cardsArray[i];
    }
    this->m_cards=gameCards;
    this->m_numOfCards=numOfCards;
    this->m_gameStatus=GameStatus::MidGame;
    this->m_currentCard=INTIALL_CARD;
    this->m_currentPlayer=INTIALL_PLAYER;
}

GameStatus Mtmchkin::getGameStatus() const {
    return this->m_gameStatus;
}

void Mtmchkin::playNextCard(){
    Competitors* temp = this->m_competitors;
    for (int i = START_NUM_OF_PLAYERS; i < this->m_numOfPlayers; ++i) {
        temp=temp->getNext();
    }
    this->m_cards[this->m_currentCard].printInfo();
    this->m_cards[this->m_currentCard].applyEncounter(*temp->getPlayer());
    temp->getPlayer()->printInfo();
    if(temp->getPlayer()->getHP()<=KNOCKEDOUT){
        this->m_gameStatus=GameStatus::Loss;
    }
    else if(temp->getPlayer()->getLevel()>=MAX_LEVEL){
        this->m_gameStatus=GameStatus::Win;
    }
    this->m_currentCard=(this->m_currentCard+NEXT_TURN)%this->m_numOfCards;
    this->m_currentPlayer=(this->m_currentPlayer+NEXT_TURN)%this->m_numOfPlayers;
}

bool Mtmchkin::isOver() const{

    return (this->m_gameStatus==GameStatus::Win || this->m_gameStatus==GameStatus::Loss);
}

Mtmchkin::~Mtmchkin() {
    Competitors* temp = m_competitors;
    for (int i = INTIALL_PLAYER; i < m_numOfPlayers; ++i) {
        m_competitors=m_competitors->getNext();
        delete temp->getPlayer();
        delete temp;
    }
    delete[] m_cards;
}