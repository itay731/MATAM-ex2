//
// Created by 97252 on 5/1/2022.
//

#include "Player.h"


Player::Player(const char* name, int maxHP, int force){
    std::string newName(name);
    this->m_name=newName;
    this->m_level=START_LEVEL;
    if(force<LEGAL_FORCE){
        this->m_force=DEFAULT_FORCE;
    }
    else {
        this->m_force = force;
    }
    if(maxHP<LEGAL_MAX_HP){
        this->m_maxHP=DEFAULT_MAX_HP;
        this->m_HP=DEFAULT_MAX_HP;
    }
    else {
        this->m_maxHP = maxHP;
        this->m_HP = maxHP;
    }
    this->m_coins=NO_COINS;
}

const char* Player::getName() const{
    return this->m_name.c_str();
}

int Player::getLevel() const{
    return this->m_level;
}

int Player::getForce() const{
    return this->m_force;
}

int Player::getMaxHP() const{
    return this->m_maxHP;
}

int Player::getHP() const{
    return this->m_HP;
}

int Player::getCoins() const{
    return this->m_coins;
}

/*
Player::Player(const Player& player) {
    std::string newName(player.getName());
    this->m_name=newName;
    this->m_level=player.getLevel();
    this->m_force=player.getForce();
    this->m_maxHP=player.getMaxHP();
    this->m_HP=player.getHP();
    this->m_coins=player.getCoins();
}
*/

bool Player::operator==(const Player& otherPlayer) const{
    if(this->m_name==otherPlayer.getName()){
        if(this->m_coins==otherPlayer.getCoins()){
            if(this->m_HP==otherPlayer.getHP()){
                if(this->m_force==otherPlayer.getForce()){
                    if(this->m_level==otherPlayer.getLevel()){
                        if(this->m_maxHP==otherPlayer.getMaxHP()){
                            return true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

Player& Player::operator=(const Player &player) {
    if(this==&player){
        return *this;
    }
    std::string newName(player.getName());
    m_name.clear();
    this->m_name=newName;
    this->m_level=player.getLevel();
    this->m_force=player.getForce();
    this->m_maxHP=player.getMaxHP();
    this->m_HP=player.getHP();
    this->m_coins=player.getCoins();
    return *this;
}
void Player::printInfo() {
    printPlayerInfo(this->m_name.c_str(), this->m_level, this->m_force, this->m_HP, this->m_coins);
}

void Player::levelUp() {
    if(this->m_level<MAXLEVEL) {
        this->m_level++;
    }
}

void Player::buff(const int addForce) {
    if(addForce>ILLEGAL) {
        this->m_force += addForce;
    }
}

void Player::heal(const int addHP) {
    if(addHP>ILLEGAL) {
        if (this->m_HP + addHP <= this->m_maxHP) {
            this->m_HP += addHP;
        } else {
            this->m_HP = this->m_maxHP;
        }
    }
}

void Player::damage(const int reduceHP) {
    if(reduceHP>ILLEGAL) {
        if (this->m_HP - reduceHP >= KNOCKEDOUT) {
            this->m_HP -= reduceHP;
        } else {
            this->m_HP = KNOCKEDOUT;
        }
    }
}

bool Player::isKnockedOut() const{
    return this->m_HP==KNOCKEDOUT;
}

void Player::addCoins(int treasure) {
    if(treasure>ILLEGAL) {
        this->m_coins += treasure;
    }
}

void Player::payment(int price) {
    this->m_coins-=price;
}

bool Player::pay(int price) {
    if(price>ILLEGAL) {
        if (this->m_coins >= price) {
            this->payment(price);
            return true;
        }
        else{
            return false;
        }
    }
    return true;
}

int Player::getAttackStrength() const {
    return (this->m_level+this->m_force);
}